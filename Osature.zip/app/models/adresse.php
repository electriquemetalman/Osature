<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class adresse extends Model
{
    protected $fillable=['localisation','email','telephone','adresse'];
}
