<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class faq extends Model
{
    protected $fillable = ['libelle', 'reponse'];
}
