<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class about extends Model
{
    //
    protected $fillable = ['security', 'guarantee', 'income', 'howework'];
}
