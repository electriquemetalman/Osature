<?php return array (
  'about' => 'App\\Http\\Livewire\\About',
  'connexion' => 'App\\Http\\Livewire\\Connexion',
  'faq' => 'App\\Http\\Livewire\\Faq',
  'new-investment' => 'App\\Http\\Livewire\\NewInvestment',
);