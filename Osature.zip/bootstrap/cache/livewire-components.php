<?php return array (
  'about' => 'App\\Http\\Livewire\\About',
  'connexion' => 'App\\Http\\Livewire\\Connexion',
  'creer-compte' => 'App\\Http\\Livewire\\CreerCompte',
  'faq' => 'App\\Http\\Livewire\\Faq',
  'new-investment' => 'App\\Http\\Livewire\\NewInvestment',
);